// Implement the aquarium dynamics in this file
// #fish1Id fish1=orange fish - 
//whenever (1) YOU CLICK SOMEWHERE in the aquarium, the orange fish
//(2)should MOVE to THAT LOCATION in (3)GRADUAL motion. In addition, when you DOUBLE CLICK //(4) on the orange fish, it should iINCREASE ITS SIZE(5) for a few seconds before RETURNING TO NORMAL(6)
//

//#fish2Id fish2=blue fish
//when you try to move the mouse CURSOR OVER(1) the blue fish, it will move to a random location(2), inside the view of the aquarium(3).

//both fish 
//Behavior: When a fish is not otherwise being interacted with, it will slowly move around //in
//random directions on its own. It will never move outside of the aquarium view though.

//three bubbles
//each bubble goes from the bottom to the top of the screen.
//when it will go out of the aquarium, it will enter a new in the bottom, random
//when you click on a bubble, it will dissapear in a fading manner. but will immeadiately
//after reaper at a random entry point in the bottom of the screen


/*

stackoverflow notes +failed attempts

function OrangeFishMove() 
{
    var $span = $("fish2Id");

    $span.fadeOut(1000, function() {
        var maxLeft = $(window).width() - $span.width();
        var maxTop = $(window).height() - $span.height();
        var leftPos = Math.floor(Math.random() * (maxLeft + 1))
        var topPos = Math.floor(Math.random() * (maxTop + 1))

        $span.css({ left: leftPos, top: topPos }).fadeIn(1000);
    });
};

OrangeFishMove();
setInterval(moveDiv, 5000);

*/
/*
function bluefishRandom(idRef) {
	var x = Math.floor(Math.random() * (window.innerWidth - $(idRef).width())) + window.pageXOffset;
	var y = Math.floor(Math.random() * (window.innerHeight - $(idRef).height())) + window.pageYOffset;

	$(idRef).css('position', 'absolute');
	$(idRef).animate({top: y, left: x});
}
$('#fish2Id').on('mouseenter', function() {
	moveWithinBounds(this);
});

*/


// 1 function that moves the fishes randomly

function fishies(FishId)
{
	//we have to set the boundries of the window for the fishes..
	
    var mHeight = $(window).height() -  $("#fish1Id").height(); 
	
	 var mWidth = $(window).width() - $("#fish1Id").width();
	
	//our fishies coordinates have to be in relation to maxwidth/height and random	
	
    var yCoord = Math.floor(Math.random() * (mHeight));
	
	 var xCoord = Math.floor(Math.random() * (mWidth));
	//they are animated so that they are random ,relatively slow )
$(FishId).animate({left:xCoord, top: yCoord}, 3500, function(){fishies(FishId)});
}
//here you call the function
fishies("#fish1Id");
fishies("#fish2Id");


//2 blue fishie get's scared by the cursor

$("#fish2Id").mouseover(function ()
						{
	//doing the same thing ..assess size+random coords
    var moveWidth = $(window).width() - $("#fish2Id").width();
    var moveHeight = $(window).height() - $("#fish2Id").height();
    var xCoord = Math.floor(Math.random() * moveWidth);
    var yCoord = Math.floor(Math.random() * moveHeight);
	//if we dont put this, the fish will not move randomly after being "scared"
	//he goes in shock basically
    $(this).stop(true, false).animate({left: xCoord, top: yCoord}, "fast", function(){fishies("#fish2Id")});
});




//3 orange fishie transforms into a puffer fish(height-width 400) om double click for
//0.3 seconds), and returns to being cute again, and goes to roam randomly

$("#fish1Id").dblclick(function ()
{  
   $(this).stop(true, false).animate
   (
	   {
		   height: 400, width: 400}
   )
	   .delay(300).animate
   (
	   {
		   //same height and width in the css for fish1
		   height: 250, width: 250}
	   , function()
	   {
		   fishies("#fish1Id")
	   }
   );
});




//orange fishie stalks the cursor ,doesnt work..i tried
$("*").click(function()
		 {
    
    var xCoord = event.pageX;
    var yCoord = event.pageY;
    
    $("#fish1Id").stop(true, false).animate({left: xCoord, top: yCoord}, function(){fishies("#fish1Id")});
});






//5 bubbles appearing in the aquarium randomly
function randombubbles(bubbleId) {
    var y = $(window).height();
    var x = Math.floor(Math.random() * ($(window).width() - 100));
    $(bubbleId).offset({
        top: y, left: x
    })
}

//6 the bubbles have to reaper

function loop(bubbleId) 
{
    randombubbles(bubbleId);
    $(bubbleId).animate
	(
		
	{
	top: -$(window).height()
    },  
	function () 
	{
        loop(bubbleId)
    }
	);
}
loop("#bubble1Id");
loop("#bubble2Id");
loop("#bubble3Id");



//Function to pop baloons on click...though not so scalable..
//i know it could have been done in way more efficient ways...
//though im not sure if i works..i did not had time to
//modify the speed so i can pop them...

$(document).ready(function()
	 {
    $("#bubble1Id").click(function()
	 {
        $("#bubble1Id").fadeOut();
		
		
    });
    $("#bubble2Id").click(function()
		 {
        $("#bubble2Id").fadeOut();
		
    });
	$("#bubble3Id").click(function()
	{
        $("#bubble3Id").fadeOut();
		

    });
});

////when you click on a bubble, it will dissapear in a fading manner. but will immeadiately
//after reaper at a random entry point in the bottom of the screen did not managed to cover..